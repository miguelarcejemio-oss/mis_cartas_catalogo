# Mis Cartas catálogo v2
Servidor para catálogo, checklists y portadas.

## Portadas
Sube una imagen a `portadas/` con el ID exacto de la colección, por ejemplo:
`panini-megacracks-2627.jpg`

La app v53 prueba `.webp`, `.jpg` y `.png` como respaldo. Para forzar prioridad absoluta desde `catalogo.json`, añade `cover_local` con la URL publicada de esa imagen.

## Actualizaciones
Cada push a `main` valida `catalogo.json` y, si es válido, despliega GitHub Pages.

### Checklists oficiales y publicación

El enriquecimiento consulta primero `official_checklists` en `fuentes.json`,
incluso cuando la colección ya existe. El adaptador Panini lee la checklist PDF
real y busca nuevos PDF enlazados en la página oficial, cruza los identificadores con el JSON público de cartas faltantes y busca
imágenes de producto en esa página. Conserva BIS, Power e índices originales;
los inserts sin número no reciben números impresos inventados. Excluye los
26 autógrafos originales de Megacracks según la política existente.

Megacracks 2025/26: la tercera edición oficial contiene 677 cartas sin autógrafos
(519 numeradas, 86 BIS, 54 Power, 14 inserts y 4 índices). El objetivo de cierre
es 692, incluyendo 15 promocionales que todavía requieren verificación. La
checklist oficial y la tienda coinciden en 609 identificadores. Las páginas de
Jugón 222, 223 y 224 se consultan independientemente; una pantalla de
JavaScript/cookies o una redirección a `panini.queue-it.net` se registra como bloqueo, nunca como una checklist vacía.

La descarga pública y `robots.txt` no acreditan permiso de republicación.
`reuse_permissions` debe contener una autorización real, con su evidencia;
este cambio no introduce permisos supuestos para Panini o CromosRepes.
Mientras falten cartas o autorización, no se modifica `catalogo.json`.
Los inserts antiguos se emparejan por serie y jugador, conservando su ID y estado.
Las referencias incompatibles SOB7 y SOB8 se conservan en `legacy_unverified_cards`
con sus datos originales: nunca se reasigna su estado a otro jugador. Esta migración
solo se aplica si la colección completa supera los controles de publicación.
Las tablas promocionales admiten `S/N` explícito; una celda vacía no acredita
que la carta carezca de número impreso.

Para comprobarlo desde Codespace:

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python scripts/enrich_collections.py --limit 20
python validate_catalog.py catalogo.json
python scripts/build_site.py
```

El despliegue sube `site/`: catálogo, configuración y portadas existentes.
No publica scripts, pruebas, PDFs de las fuentes ni informes de verificación.
La comprobación de publicación impide desplegar una colección declarada completa
si su número de cartas no coincide o contiene identificadores duplicados.
