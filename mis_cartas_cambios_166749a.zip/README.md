# Mis Cartas catálogo v2
Servidor para catálogo, checklists y portadas.

## Portadas
Sube una imagen a `portadas/` con el ID exacto de la colección, por ejemplo:
`panini-megacracks-2627.jpg`

La app v53 prueba `.webp`, `.jpg` y `.png` como respaldo. Para forzar prioridad absoluta desde `catalogo.json`, añade `cover_local` con la URL publicada de esa imagen.

## Actualizaciones
Cada push a `main` valida `catalogo.json` y, si es válido, despliega GitHub Pages.

## Enriquecimiento verificable

Los informes tienen propietarios distintos:
- `portadas/descubrimiento.json`: `collection_discovery.py` descubre colecciones.
- `portadas/actualizaciones.json`: `detect_updates.py` informa de actualizaciones.
- `portadas/enriquecimiento.json`: `enrich_collections.py` verifica y publica.
- `portadas/discovery_snapshot.json`: conserva candidatas para reintentos.

El enriquecimiento realiza solicitudes HTTPS públicas respetando robots.txt,
el intervalo de cinco segundos y los límites de tamaño. Examina únicamente
metadatos, descripción y tablas de checklist; ignora tablas de usuarios,
faltas, repetidas y notas. Una ficha vacía se comprueba también en su ruta
pública `/coleccion/cromos/`. No accede a cuentas ni sortea bloqueos.

Busca imágenes etiquetadas como portada/álbum y checklists enlazadas en la
ficha. Admite tablas HTML y PDF de texto con nombre, año, total explícito e
identificadores inequívocos. Las estructuras desconocidas, PDFs escaneados,
conteos ambiguos y tablas incompletas se rechazan, con el motivo preciso.
No basta con que una URL responda 200: también se decodifica la imagen.

Para publicar contenidos de un host debe existir autorización documentada en
`fuentes.json`, independiente de robots y del acceso público. Formato de la
clave opcional (no se incluye ninguna autorización ficticia):

```json
{
  "reuse_permissions": [
    {
      "host": "HOST_AUTORIZADO",
      "publication_allowed": true,
      "evidence_url": "URL_DEL_PERMISO_O_LICENCIA"
    }
  ]
}
```

CromosRepes exige permiso previo por escrito para reproducción/publicación:
https://cromosrepes.com/ayuda/legal. Una suscripción no acredita ese permiso.
Cada host de una checklist externa o imagen necesita su propia autorización.
Se siguen los enlaces externos que disponen de ella; no hay lista cerrada de
fabricantes. No se guardan credenciales ni datos de coleccionistas.

Solo se añaden colecciones nuevas con portada y checklist completas
verificadas. Las colecciones y cartas existentes nunca se sustituyen ni se
renumeran; los estados personales no se modifican. Se conservan números como
`01`, `EL-1` o `bis` y firmas impresas; se excluyen autógrafos expresamente
originales. Si no hay altas, `catalogo.json` conserva incluso sus bytes.

Las ejecuciones procesan hasta 20 candidatas por turno, ordenadas por su
última comprobación para evitar que un bloqueo impida revisar el resto.
Para una comprobación breve: `python scripts/enrich_collections.py --limit 4`.
Las pendientes continúan en ejecuciones posteriores incluso si el índice
no vuelve a marcarlas como nuevas o si hay una caída temporal de la fuente.

Pruebas: `python -m pip install -r requirements.txt` y
`python -m unittest discover -s tests -v`.
GitHub Actions ejecuta las pruebas, valida el catálogo, guarda los cuatro
informes y despliega solo si la fase anterior termina correctamente.
